Hello Windows 95/NT user,

This zip file contains two files:

yomama.ini
yomama32.exe

In the yomama.ini file you can change some settings to screen out the
rudest snaps.  Just have it in the same directory as the executable.

Have fun, and let me know if you like it,

Pimpdaddy.
dhubbard@pimpdaddy.com
http://www.pimpdaddy.com